import MosaicRegion from "./MosaicRegion";

export default MosaicRegion;