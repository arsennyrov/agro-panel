import MosaicCompany from "./MosaicCompany";

export default MosaicCompany;