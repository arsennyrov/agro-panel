import Chart from './PieChart'

export default Chart;
