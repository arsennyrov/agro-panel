import Mosaic from "./Mosaic";

export default Mosaic;