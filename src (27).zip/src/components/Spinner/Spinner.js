import React from 'react';
import './Spinner.css';

const Spinner = () => {

  return (
    <div className="loadingio-spinner-spinner-qim7t3m3lna">
        <div className="ldio-7s6bt946xqx">
        <div></div><div></div><div></div><div></div><div></div><div></div>
        <div></div><div></div><div></div><div></div><div></div><div></div>
        </div>
    </div>
  );
};

export default Spinner;