export function problems() {
  return [  
  {
    id: "1001",
    name: 'Рапс яровой',
    measure: 'Га',
    value: 22341,
    percent: 3,
    info: true,
  },
  {
    id: "1002",
    name: 'Яровая пшеница',
    measure: 'Га',
    value: 14700,
    percent: 35,
    info: false  ,
  },
  {
    id: "1003",
    name: 'Подсолнечник',
    measure: 'Га',
    value: 3750,
    percent: 40,
    info: true,
  },
 
  {
    id: "2001",
    name: 'Подсолнечник',
    measure: 'Га',
    value: 22341,
    percent: 0,
    info: true,
  },
  {
    id: "2002",
    name: 'Яровая пшеница',
    measure: 'Га',
    value: 14700,
    percent: 100,
    info: true,
  },
  {
    id: "2003",
    name: 'Рапс яровой',
    measure: 'Га',
    value: 3750,
    percent: 60,
    info: true,
  },
]
};

