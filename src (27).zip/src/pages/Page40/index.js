import Page4 from "./Page4";

export default Page4;