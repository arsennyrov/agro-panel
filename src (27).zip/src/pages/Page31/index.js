import Page31 from "./Page31";

export default Page31;