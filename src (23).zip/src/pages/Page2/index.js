import Page2 from "./Page2";

export default Page2;
