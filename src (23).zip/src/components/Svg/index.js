import SvgHome from './SvgHome';

export default  SvgHome;