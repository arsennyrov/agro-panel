import Puzzl from './Puzzl'

export default Puzzl;