import Bar from './Bar'

export default Bar;
