import TableHead from './TableHead';

export default TableHead;