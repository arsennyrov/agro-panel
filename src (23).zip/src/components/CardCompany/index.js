import CardCompany from './CardCompany';

export default CardCompany;