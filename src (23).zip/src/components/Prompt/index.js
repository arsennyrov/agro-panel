import Prompt from './Prompt'

export default Prompt;