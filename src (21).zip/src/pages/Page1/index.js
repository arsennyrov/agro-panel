import Page1 from "./Page1";

export default Page1;
