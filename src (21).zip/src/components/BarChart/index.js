import Chart from './BarChart'

export default Chart;
