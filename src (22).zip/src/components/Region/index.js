import Region from './Region';

export default Region;