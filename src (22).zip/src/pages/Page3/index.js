import Page3 from "./Page3";

export default Page3;