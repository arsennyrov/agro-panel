import { createSlice } from '@reduxjs/toolkit';

// import { area, regions } from '../containers/utils';

const initialState = {

}

export const utilSlice = createSlice({
  name: 'toolkit1',
  initialState,  
  reducers: {}
})

export const {} = utilSlice.actions

export default utilSlice.reducer

 